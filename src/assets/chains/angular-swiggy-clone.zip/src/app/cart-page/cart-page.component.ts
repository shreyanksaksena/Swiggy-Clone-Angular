import { Component } from '@angular/core';
import { CartHandlerService } from '../cart-handler.service';
import { RestaurantHandlerService } from '../restaurant-handler.service';
import { CartItem, RestaurantDetails } from '../../types';
import { NavbarComponent } from '../navbar/navbar.component';
import { NgFor, NgIf } from '@angular/common';
@Component({
  selector: 'app-cart-page',
  standalone: true,
  imports: [NavbarComponent, NgFor, NgIf],
  templateUrl: './cart-page.component.html',
  styleUrl: './cart-page.component.scss'
})
export class CartPageComponent {
  
  restaurantDetails!:RestaurantDetails;
  cartItems!:CartItem[];

  constructor (private cartHandler: CartHandlerService, private restaurantHandler: RestaurantHandlerService) {
    const resQueryRes = this.restaurantHandler.getRestaurantFromId(this.cartHandler.getCurrentRestaurantId());
    if (resQueryRes) {
      this.restaurantDetails = resQueryRes as RestaurantDetails;
      this.cartItems = this.cartHandler.getCartItems();
    }
  };

  // Function to update the quantity of the item when the item is changed from the template
  updateQuantity(item: CartItem, newQuantity: number) {
    this.cartItems.
  }


}
