import { Component } from '@angular/core';

@Component({
  selector: 'app-favourite-restaurants',
  standalone: true,
  imports: [],
  templateUrl: './favourite-restaurants.component.html',
  styleUrl: './favourite-restaurants.component.scss'
})
export class FavouriteRestaurantsComponent {

}
