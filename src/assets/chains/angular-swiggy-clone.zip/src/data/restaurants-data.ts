import { RestaurantDetails } from "../types";
export const restaurantsByCity:string[] = [
    'Best Restaurants in Hyderabad',
    'Best Restaurants in Kolkata',
    'Best Restaurants in Chennai',
    'Best Restaurants in Chandigarh',
    'Best Restaurants in Ahmedabad',
    'Best Restaurants in Jaipur',
    'Best Restaurants in Nagpur',
    'Best Restaurants in Bhubaneswar',
];

export const restaurantsByCuisine:string[] = [
    'Chinese Restaurant Near Me',
    'South Indian Restaurant Near Me',
    'Indian Restaurant Near Me',
    'Kerela Restaurant Near Me',
    'Korean Restaurant Near Me',
    'North Indian Restaurant Near Me',
    'Seafood Restaurant Near Me',
    'Bengali Restaurant Near Me',
    'Punjabi Restaurant Near Me',
    'Italian Restaurant Near Me',
    'Andhra Restaurant Near Me',
    'Biryani Restaurant Near Me',
];


export const restaurantMenus:RestaurantDetails[] = [
    {
        id: "subway",
        name: "Subway",
        rating: 4.2,
        outlet: "Egattur",
        deliveryTime: "40-45 mins",
        tags: ["Salads", "Snacks"],
        imgSrc: "../../assets/images/restaurants/subway.avif",
        menu: [
            {
                id: 1,
                name: "Potato Chilli Cheese",
                price: 279,
                imgSrc: "../../assets/images/menu/subway/potato-chilli-cheese.avif",
                description: "Hot toasted sub loaded with 1.5x potato patty and real mozz cheese, topped with mint mayo, onions and capsicum and cheese slice. Serving size: 15cm - 238 g/518 kcal, 30cm - 476 g/1036 kcal. Allergens - Contains cereals containing gluten, milk, soy.",
                veg: true
            },
            {
                id: 2,
                name: "Chicken Melt Keema",
                price:  279,
                imgSrc: "../../assets/images/menu/subway/chicken-keema-melt.avif",
                description: "Hot and cheesy toasted sub with 1.5x chicken keema, real mozz cheese, onion, capsicum, chili mayo and cheese slice. Serving size: 15cm - 233 g/569 kcal, 30cm - 466 g/1138 kcal.  Allergens - Contains cereals containing gluten, milk, soy.",
                veg: false
            },
            {
                id: 3,
                name: "Cheesy Paneer Tikka",
                price: 319,
                imgSrc: "../../assets/images/menu/subway/cheesy-paneer-tikka.avif",
                description: "Double the paneer, with real mozz cheese. Indulge in hot cheesy paneer melt loaded with paneer, tangy tandoori sauce, fresh veggies and cheese slice. Serving size: 15cm - 299 g/678 kcal, 30cm - 598 g/1356 kcal.  Allergens - Contains cereals containing gluten, milk, soy.",
                veg: true
            }
        ],
        topPicks: [
            {
                dish: {
                    id: 3,
                    name: "Cheesy Paneer Tikka",
                    price: 319,
                    imgSrc: "../../assets/images/menu/subway/cheesy-paneer-tikka.avif",
                    description: "Double the paneer, with real mozz cheese. Indulge in hot cheesy paneer melt loaded with paneer, tangy tandoori sauce, fresh veggies and cheese slice. Serving size: 15cm - 299 g/678 kcal, 30cm - 598 g/1356 kcal.  Allergens - Contains cereals containing gluten, milk, soy.",
                    veg: true
                },
                imgSrc: "../../assets/images/menu/subway/top-picks/cheesy-paneer-tikka.avif"
            },
            {
                dish: {
                    id: 1,
                    name: "Potato Chilli Cheese",
                    price: 279,
                    imgSrc: "../../assets/images/menu/subway/potato-chilli-cheese.avif",
                    description: "Hot toasted sub loaded with 1.5x potato patty and real mozz cheese, topped with mint mayo, onions and capsicum and cheese slice. Serving size: 15cm - 238 g/518 kcal, 30cm - 476 g/1036 kcal. Allergens - Contains cereals containing gluten, milk, soy.",
                    veg: true
                },
                imgSrc: "../../assets/images/menu/subway/top-picks/potato-chilli-cheese.avif",
            },
            
        ]
       
    },
    {
        id: "dominos",
        name: "Domino's Pizza",
        rating: 3.8,
        outlet: "Coromandel Plaza",
        deliveryTime: "20-25 mins",
        tags: ["Pizzas", "Italian"],
        imgSrc: "../../assets/images/restaurants/dominos.avif",
        menu: [
            {
                id: 1,
                name: "Peppy Paneer Cheese Burst",
                price: 558,
                imgSrc: "../../assets/images/menu/dominos/peppy-paneer-cheese-burst.avif",
                description: "Now in 3 New Flavours - Molten Cheese Indulgence with Flavorful trio of juicy paneer, crisp capsicum & spicy red paprika",
                veg: true
            },
            {
                id: 2,
                name: "Farmhouse Cheese Burst",
                price: 558,
                imgSrc: "../../assets/images/menu/dominos/farmhouse-cheese-burst.avif",
                description: "Now in 3 New Flavours - Molten Cheese Indulgence with combination of onion, capsicum, tomato & grilled mushroom",
                veg: true
            },
            
        ],
        topPicks: [
            {
                dish: {
                    id: 2,
                    name: "Farmhouse Cheese Burst",
                    price: 558,
                    imgSrc: "../../assets/images/menu/dominos/farmhouse-cheese-burst.avif",
                    description: "Now in 3 New Flavours - Molten Cheese Indulgence with combination of onion, capsicum, tomato & grilled mushroom",
                    veg: true
                },
                imgSrc: "../../assets/images/menu/dominos/top-picks/farm-house-cheese-burst.avif"
            },
            {
                dish: {
                    id: 1,
                    name: "Peppy Paneer Cheese Burst",
                    price: 558,
                    imgSrc: "../../assets/images/menu/dominos/peppy-paneer-cheese-burst.avif",
                    description: "Now in 3 New Flavours - Molten Cheese Indulgence with Flavorful trio of juicy paneer, crisp capsicum & spicy red paprika",
                    veg: true
                },
                imgSrc: "../../assets/images/menu/dominos/top-picks/peppy-paneer-cheese-burst.avif"
            }
        ]
    }
]